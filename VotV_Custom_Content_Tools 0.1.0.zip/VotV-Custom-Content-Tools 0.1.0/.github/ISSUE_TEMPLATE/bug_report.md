---
name: Bug report
about: Report a reproducible problem
title: "[Bug]: "
labels: bug
assignees: ''
---

## Tool and version

- Tool: 
- Tool version: 
- Language: English / Russian
- Windows version: 
- Python version: 

## Describe the problem

## Steps to reproduce

1. 
2. 
3. 

## Expected behaviour

## Actual behaviour

## Logs or screenshots

Remove usernames, personal file paths, and private data. Do not attach models or images unless you have permission to redistribute them.
