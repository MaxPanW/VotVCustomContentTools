---
name: Feature request
about: Suggest a focused improvement
title: "[Feature]: "
labels: enhancement
assignees: ''
---

## Problem or use case

Describe what is difficult or missing today.

## Proposed solution

Describe the feature and how it should behave.

## Alternatives considered

## Additional context
